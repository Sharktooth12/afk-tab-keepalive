// State is kept PER WINDOW: afkState = { windows: { [windowId]: {...} } }
// Every tab in a window shows the same widget, driven by that window's entry.
const TICK_ALARM = 'afk-tick';
const STOP_PREFIX = 'afk-stop:';
const DEFAULT_WIN = {
  away: false, cycling: false, cycleStart: null, maxMs: 0, idleSeconds: 120,
  originTabId: null, nextIndex: 0
};
const DEFAULT_SETTINGS = {
  idleSeconds: 120, maxMinutes: 30, tickSeconds: 30, maxGapMinutes: 4, dwellSeconds: 1.5, tabGapSeconds: 10,
  clickXPercent: 50, clickY: 10, scope: 'window', restoreOrigin: true, skipPinned: false,
  whitelist: [], blocklist: [], cancelOn: 'page'
};

let busy = false;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const num = (v, min, max, def) => {
  v = Number(v);
  return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
};

// ---- serialized storage access (prevents lost updates between async handlers) ----
let chain = Promise.resolve();
function withLock(fn) {
  const p = chain.then(fn, fn);
  chain = p.catch(() => {});
  return p;
}
async function readWins() {
  const { afkState } = await chrome.storage.local.get('afkState');
  return (afkState && afkState.windows) || {};
}
function mutate(fn) {
  return withLock(async () => {
    const windows = await readWins();
    const r = await fn(windows);
    await chrome.storage.local.set({ afkState: { windows } });
    return r;
  });
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const D = DEFAULT_SETTINGS;
  return {
    idleSeconds: num(s.idleSeconds, 15, 1800, D.idleSeconds),
    maxMinutes: num(s.maxMinutes, 1, 120, D.maxMinutes),
    tickSeconds: num(s.tickSeconds, 30, 240, D.tickSeconds),
    maxGapMinutes: num(s.maxGapMinutes, 1, 10, D.maxGapMinutes),
    dwellSeconds: num(s.dwellSeconds, 0.5, 10, D.dwellSeconds),
    tabGapSeconds: num(s.tabGapSeconds, 10, 120, D.tabGapSeconds),
    clickXPercent: num(s.clickXPercent, 0, 100, D.clickXPercent),
    clickY: num(s.clickY, 0, 500, D.clickY),
    scope: s.scope === 'all' ? 'all' : 'window',
    restoreOrigin: s.restoreOrigin !== false,
    skipPinned: !!s.skipPinned,
    whitelist: Array.isArray(s.whitelist) ? s.whitelist : [],
    blocklist: Array.isArray(s.blocklist) ? s.blocklist : [],
    cancelOn: s.cancelOn === 'system' ? 'system' : 'page'
  };
}

// The user must tick the disclaimer checkbox on the options page before Away mode can be used.
async function isAcknowledged() {
  const { afkAck } = await chrome.storage.local.get('afkAck');
  return !!(afkAck && afkAck.acknowledged === true);
}

async function applyIdleInterval() {
  const s = await getSettings();
  chrome.idle.setDetectionInterval(Math.round(s.idleSeconds));
}
applyIdleInterval();
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'local' && c.settings) applyIdleInterval();
});

async function resetAll() {
  await chrome.alarms.clearAll();
  await chrome.storage.local.set({ afkState: { windows: {} }, afkPos: {} });
}

chrome.runtime.onInstalled.addListener(async (details) => {
  await resetAll();
  if (details.reason === 'install' && !(await isAcknowledged())) chrome.runtime.openOptionsPage();
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const t of tabs) {
    try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }); } catch (e) {}
  }
});
chrome.runtime.onStartup.addListener(resetAll);
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.windows.onRemoved.addListener(async (windowId) => {
  await mutate((w) => { delete w[windowId]; });
  await chrome.alarms.clear(STOP_PREFIX + windowId);
  await syncTickAlarm();
});

// ---- messages from the widget ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  const tab = sender.tab;
  if (msg.type === 'hello') { sendResponse({ windowId: tab ? tab.windowId : null }); return; }
  if (msg.type === 'toggle' && tab) toggle(tab, msg.info);
  if (msg.type === 'openOptions') chrome.runtime.openOptionsPage();
  if (msg.type === 'userInput' && tab) onUserInput(msg.kind, tab);
  if (msg.type === 'savePos' && tab) {
    withLock(async () => {
      const { afkPos } = await chrome.storage.local.get('afkPos');
      await chrome.storage.local.set({ afkPos: { ...(afkPos || {}), [tab.windowId]: msg.pos } });
    });
  }
});

const hostOf = (tab) => { try { return ' on ' + new URL(tab.url).hostname; } catch (e) { return ''; } };

async function onUserInput(kind, tab) {
  const wins = await readWins();
  const st = wins[tab.windowId];
  if (!st || !st.cycling) return;
  const s = await getSettings();
  if (s.cancelOn !== 'page') return;
  await stopWindows(s.scope === 'all' ? Object.keys(wins).map(Number) : [tab.windowId],
    'Real ' + kind + ' input detected' + hostOf(tab));
}

async function normalWindowIds() {
  return (await chrome.windows.getAll({ windowType: 'normal' })).map((w) => w.id);
}

async function toggle(tab, info) {
  const s = await getSettings();
  const wins = await readWins();
  const cur = wins[tab.windowId];
  const on = cur && (cur.away || cur.cycling);
  const targets = s.scope === 'all' ? await normalWindowIds() : [tab.windowId];
  if (on) {
    const d = info ? ' [' + info.pointerType + ', held ' + info.heldMs + 'ms, ' + info.sinceVisibleMs + 'ms after tab shown]' : '';
    await stopWindows(targets, 'Pill was clicked' + hostOf(tab) + d);
  } else {
    if (!(await isAcknowledged())) { chrome.runtime.openOptionsPage(); return; }   // disclaimer not accepted yet
    await mutate((w) => {
      for (const id of targets) w[id] = { ...DEFAULT_WIN, away: true, idleSeconds: s.idleSeconds };
    });
  }
}

chrome.idle.onStateChanged.addListener(async (idleState) => {
  const wins = await readWins();
  const ids = Object.keys(wins).map(Number);
  if ((idleState === 'idle' || idleState === 'locked')) {
    const toStart = ids.filter((id) => wins[id].away && !wins[id].cycling);
    for (const id of toStart) await startCycling(id);
    if (toStart.length) tick();
  } else if (idleState === 'active') {
    const cycling = ids.filter((id) => wins[id].cycling);
    if (!cycling.length) return;
    const s = await getSettings();
    if (s.cancelOn !== 'system') return;
    const real = await chrome.idle.queryState(15);
    if (real === 'active') await stopWindows(cycling, 'System reported keyboard/mouse activity');
  }
});

async function startCycling(windowId) {
  if (!(await isAcknowledged())) return;
  const s = await getSettings();
  let originTabId = null;
  try {
    const [t] = await chrome.tabs.query({ active: true, windowId });
    if (t) originTabId = t.id;
  } catch (e) { return; }
  const cycleStart = Date.now();
  const maxMs = s.maxMinutes * 60 * 1000;
  await mutate((w) => {
    w[windowId] = { ...(w[windowId] || DEFAULT_WIN), away: true, cycling: true, cycleStart, maxMs, originTabId, nextIndex: 0 };
  });
  await chrome.alarms.create(STOP_PREFIX + windowId, { when: cycleStart + maxMs });
  await syncTickAlarm();
}

async function stopWindows(ids, reason) {
  const s = await getSettings();
  const wins = await readWins();
  const restore = [];
  for (const id of ids) {
    const st = wins[id];
    if (!st) continue;
    if (st.cycling && s.restoreOrigin && st.originTabId != null) restore.push(st.originTabId);
    await chrome.alarms.clear(STOP_PREFIX + id);
  }
  await mutate((w) => { for (const id of ids) delete w[id]; });
  await chrome.storage.local.set({ afkLastStop: { reason: reason || 'Stopped', at: Date.now() } });
  for (const tabId of restore) {
    try { await chrome.tabs.update(tabId, { active: true }); } catch (e) {}
  }
  await syncTickAlarm();
}

async function syncTickAlarm() {
  const wins = await readWins();
  const any = Object.values(wins).some((w) => w.cycling);
  const existing = await chrome.alarms.get(TICK_ALARM);
  if (!any) { if (existing) await chrome.alarms.clear(TICK_ALARM); return; }
  if (!existing) {
    const s = await getSettings();
    await chrome.alarms.create(TICK_ALARM, { periodInMinutes: s.tickSeconds / 60 });
  }
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === TICK_ALARM) tick();
  else if (a.name.startsWith(STOP_PREFIX)) stopWindows([Number(a.name.slice(STOP_PREFIX.length))], 'Time limit reached');
});

const hostMatches = (host, list) => list.some((d) => host === d || host.endsWith('.' + d));

function eligible(tab, s) {
  if (!tab.url || !/^https?:/i.test(tab.url)) return false;
  if (s.skipPinned && tab.pinned) return false;
  let host;
  try { host = new URL(tab.url).hostname.toLowerCase(); } catch (e) { return false; }
  if (hostMatches(host, s.blocklist)) return false;
  if (s.whitelist.length && !hostMatches(host, s.whitelist)) return false;
  return true;
}

async function waitComplete(tabId, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    try { if ((await chrome.tabs.get(tabId)).status === 'complete') return; } catch (e) { return; }
    await sleep(250);
  }
}

async function tick() {
  if (busy) return;
  busy = true;
  try {
    const s = await getSettings();
    const wins = await readWins();
    for (const idStr of Object.keys(wins)) {
      const id = Number(idStr);
      const st = wins[idStr];
      if (!st.cycling) continue;
      if (Date.now() - st.cycleStart >= st.maxMs) { await stopWindows([id], 'Time limit reached'); continue; }
      await cycleWindow(id, s);
    }
  } finally {
    busy = false;
  }
}

const lastSwitchByWin = {};   // windowId -> time of last programmatic tab switch

async function cycleWindow(windowId, s) {
  let tabs;
  try { tabs = (await chrome.tabs.query({ windowId })).filter((t) => eligible(t, s)); } catch (e) { return; }
  if (!tabs.length) return;

  const rounds = Math.max(1, Math.floor((s.maxGapMinutes * 60) / s.tickSeconds));
  const gapMsForFill = s.tabGapSeconds * 1000;
  // Enough visits to cover every tab within the max gap, but also fill each round at the minimum
  // gap so switching is continuous (e.g. 30s rounds / 10s gap = 3 switches per round).
  const coverage = Math.ceil(tabs.length / rounds);
  const fill = tabs.length > 1 ? Math.max(1, Math.floor((s.tickSeconds * 1000) / gapMsForFill)) : 1;
  const perTick = Math.max(1, coverage, fill);
  const dwellMs = s.dwellSeconds * 1000;
  const gapMs = s.tabGapSeconds * 1000;

  for (let i = 0; i < perTick; i++) {
    // never switch tabs more often than the configured minimum gap (>= 10 s)
    const last = lastSwitchByWin[windowId];
    if (last) await sleep(Math.max(0, last + gapMs - Date.now()));
    const st = (await readWins())[windowId];
    if (!st || !st.cycling) return;
    const idx = st.nextIndex % tabs.length;
    const tab = tabs[idx];
    await mutate((w) => { if (w[windowId]) w[windowId].nextIndex = (idx + 1) % tabs.length; });
    try {
      lastSwitchByWin[windowId] = Date.now();
      await chrome.tabs.update(tab.id, { active: true });
      await waitComplete(tab.id, 10000);          // discarded/reloading tabs need time before we click
      await sleep(dwellMs);
      const now = (await readWins())[windowId];
      if (!now || !now.cycling) return;
      await chrome.scripting.executeScript({
        target: { tabId: tab.id }, func: clickTopCenter, args: [s.clickXPercent, s.clickY]
      });
    } catch (e) { /* tab closed or not scriptable: skip */ }
  }
}

// Runs inside the page (must be self-contained)
function clickTopCenter(xPct, y) {
  const x = Math.min(window.innerWidth - 1, Math.round((window.innerWidth * xPct) / 100));
  let el = document.elementFromPoint(x, y) || document.body;
  const risky = 'a,button,input,select,textarea,summary,label,[role="button"],[role="link"],[onclick]';
  if (el.id === '__afk_pill_host' || (el.closest && el.closest(risky))) el = document.body;
  const base = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0 };
  const ptr = { ...base, pointerType: 'mouse', isPrimary: true };
  el.dispatchEvent(new PointerEvent('pointermove', ptr));
  el.dispatchEvent(new MouseEvent('mousemove', base));
  el.dispatchEvent(new PointerEvent('pointerdown', ptr));
  el.dispatchEvent(new MouseEvent('mousedown', base));
  el.dispatchEvent(new PointerEvent('pointerup', ptr));
  el.dispatchEvent(new MouseEvent('mouseup', base));
  el.dispatchEvent(new MouseEvent('click', base));
}
