const D = {
  idleSeconds: 120, maxMinutes: 30, tickSeconds: 30, maxGapMinutes: 4, dwellSeconds: 1.5, tabGapSeconds: 10,
  clickXPercent: 50, clickY: 10, scope: 'window', restoreOrigin: true, skipPinned: false,
  whitelist: [], blocklist: [], cancelOn: 'page'
};
const NUM = {
  idleSeconds: [15, 1800], maxMinutes: [1, 120], tickSeconds: [30, 240], maxGapMinutes: [1, 10],
  dwellSeconds: [0.5, 10], tabGapSeconds: [10, 120], clickXPercent: [0, 100], clickY: [0, 500]
};
const $ = (id) => document.getElementById(id);

function fill(s) {
  for (const k of Object.keys(NUM)) $(k).value = s[k];
  $('scope').value = s.scope;
  $('cancelOn').value = s.cancelOn;
  $('restoreOrigin').checked = s.restoreOrigin;
  $('skipPinned').checked = s.skipPinned;
  $('whitelist').value = s.whitelist.join('\n');
  $('blocklist').value = s.blocklist.join('\n');
  checkGap();
}

const domains = (t) => t.split('\n')
  .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
  .filter(Boolean);

function collect() {
  const s = {};
  for (const [k, [min, max]] of Object.entries(NUM)) {
    const v = Number($(k).value);
    s[k] = Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : D[k];
  }
  s.scope = $('scope').value;
  s.cancelOn = $('cancelOn').value;
  s.restoreOrigin = $('restoreOrigin').checked;
  s.skipPinned = $('skipPinned').checked;
  s.whitelist = domains($('whitelist').value);
  s.blocklist = domains($('blocklist').value);
  return s;
}

function checkGap() {
  $('gapWarn').textContent = Number($('maxGapMinutes').value) >= 5
    ? 'Warning: a gap of 5+ minutes may miss a 5-minute check-in.' : '';
}
$('maxGapMinutes').addEventListener('input', checkGap);

function flash(t) { $('msg').textContent = t; setTimeout(() => ($('msg').textContent = ''), 1500); }

chrome.storage.local.get('settings').then(({ settings }) => fill({ ...D, ...(settings || {}) }));
$('save').onclick = async () => {
  const s = collect();
  await chrome.storage.local.set({ settings: s });
  fill(s);
  flash('Saved');
};
$('reset').onclick = async () => {
  await chrome.storage.local.set({ settings: { ...D } });
  fill(D);
  flash('Reset');
};

chrome.storage.local.get('afkLastStop').then(({ afkLastStop: l }) => {
  if (l) $('last').textContent = 'Last stop: ' + l.reason + ' (' + new Date(l.at).toLocaleString() + ')';
});

// Disclaimer acknowledgement: required before Away mode will start. Stored separately so "Reset" doesn't clear it.
chrome.storage.local.get('afkAck').then(({ afkAck }) => { $('ack').checked = !!(afkAck && afkAck.acknowledged); showAck(); });
$('ack').addEventListener('change', async () => {
  await chrome.storage.local.set({ afkAck: { acknowledged: $('ack').checked, at: Date.now() } });
  showAck();
});
function showAck() {
  $('ackState').textContent = $('ack').checked ? 'Accepted - Away mode is enabled.' : 'Not accepted - Away mode is disabled until you tick the box.';
  $('ackState').style.color = $('ack').checked ? '#2e7d32' : '#c62828';
}
