(() => {
  if (window.top !== window) return;

  // If an older copy of this widget exists (e.g. extension reloaded), tear it down and replace it.
  document.dispatchEvent(new CustomEvent('__afk_pill_dispose'));
  const old = document.getElementById('__afk_pill_host');
  if (old) old.remove();

  const ac = new AbortController();
  const sig = { signal: ac.signal };
  let state = { away: false, cycling: false, cycleStart: null, maxMs: 0, idleSeconds: 120 };
  let windowId = null;
  let pos = null;            // { fx, fy } fractions of the free viewport area, shared by every tab in this window
  let timer = null;
  let ready = false;

  const host = document.createElement('div');
  host.id = '__afk_pill_host';
  // Hidden until the real window state is loaded, so a freshly opened/reloaded tab never flashes a reset widget.
  host.style.cssText = 'all:initial;display:block;position:fixed;z-index:2147483647;right:16px;bottom:16px;visibility:hidden;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      .pill{font:600 12px/1 system-ui,sans-serif;display:flex;align-items:center;gap:8px;
        padding:8px 10px 8px 12px;border-radius:999px;color:#fff;cursor:pointer;user-select:none;
        touch-action:none;box-shadow:0 2px 8px rgba(0,0,0,.35);background:#2e7d32;opacity:.92;white-space:nowrap}
      .pill.away{background:#c62828}
      .pill.cycling{background:#e65100}
      .dot{width:8px;height:8px;border-radius:50%;background:#fff}
      .gear{font-size:14px;line-height:1;opacity:.8;padding:0 2px;cursor:pointer}
      .gear:hover{opacity:1}
    </style>
    <div class="pill"><span class="dot"></span><span class="label"></span><span class="gear" title="Settings">&#9881;</span></div>`;
  const pill = root.querySelector('.pill');
  const label = root.querySelector('.label');
  const gear = root.querySelector('.gear');
  document.documentElement.appendChild(host);

  function dispose() {
    ac.abort();
    if (timer) clearInterval(timer);
    host.remove();
  }
  document.addEventListener('__afk_pill_dispose', dispose, { once: true });

  const fmt = (ms) => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  };
  const fmtIdle = (sec) => (sec % 60 === 0 ? sec / 60 + ' min' : sec + 's');

  function render() {
    pill.className = 'pill' + (state.cycling ? ' cycling' : state.away ? ' away' : '');
    if (state.cycling) label.textContent = 'Away · ' + fmt(state.cycleStart + state.maxMs - Date.now()) + ' left';
    else if (state.away) label.textContent = 'Away · starts after ' + fmtIdle(state.idleSeconds) + ' idle';
    else label.textContent = 'At keyboard';
    if (state.cycling && !timer) timer = setInterval(render, 1000);
    if (!state.cycling && timer) { clearInterval(timer); timer = null; }
    applyPos();
  }

  // ---- position (same place on every tab of this window) ----
  function applyPos() {
    if (!pos) return;
    const r = host.getBoundingClientRect();
    const x = Math.max(0, (window.innerWidth - r.width)) * pos.fx;
    const y = Math.max(0, (window.innerHeight - r.height)) * pos.fy;
    host.style.left = x + 'px'; host.style.top = y + 'px';
    host.style.right = 'auto'; host.style.bottom = 'auto';
  }
  function placePx(x, y) {
    const r = host.getBoundingClientRect();
    const mx = Math.max(1, window.innerWidth - r.width), my = Math.max(1, window.innerHeight - r.height);
    pos = { fx: Math.min(1, Math.max(0, x / mx)), fy: Math.min(1, Math.max(0, y / my)) };
    applyPos();
    return pos;
  }
  window.addEventListener('resize', applyPos, sig);

  // ---- load this window's state ----
  function winState(afkState) {
    const w = afkState && afkState.windows && afkState.windows[windowId];
    return w || { away: false, cycling: false, cycleStart: null, maxMs: 0, idleSeconds: state.idleSeconds };
  }
  async function load() {
    try {
      if (windowId == null) {
        const r = await chrome.runtime.sendMessage({ type: 'hello' });
        windowId = r && r.windowId;
      }
      const r = await chrome.storage.local.get(['afkState', 'afkPos', 'afkLastStop']);
      state = winState(r.afkState);
      const p = r.afkPos && r.afkPos[windowId];
      if (p) pos = p;
      showLast(r.afkLastStop);
      render();
      host.style.visibility = 'visible';
      ready = true;
    } catch (e) { /* extension reloaded; this orphan will be replaced on next injection */ }
  }

  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local' || windowId == null) return;
    if (c.afkState) { state = winState(c.afkState.newValue); render(); }
    if (c.afkPos) {
      const p = c.afkPos.newValue && c.afkPos.newValue[windowId];
      if (p) { pos = p; applyPos(); }
    }
    if (c.afkLastStop) showLast(c.afkLastStop.newValue);
  });

  // Real user input detection (synthetic events have isTrusted === false)
  let visibleAt = performance.now();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      visibleAt = performance.now();
      load();                                  // resync in case a storage event was missed while hidden
    }
  }, sig);
  window.addEventListener('pageshow', (e) => { if (e.persisted) { visibleAt = performance.now(); load(); } }, sig);

  let lastSent = 0;
  function userInput(kind) {
    if (!ready || !state.cycling) return;
    if (performance.now() - visibleAt < 1500) return;      // ignore layout-generated events after a tab switch
    const now = Date.now();
    if (now - lastSent < 1000) return;
    lastSent = now;
    try { chrome.runtime.sendMessage({ type: 'userInput', kind }); } catch (e) {}
  }
  const opts = { capture: true, passive: true, signal: ac.signal };
  window.addEventListener('mousemove', (e) => {
    if (e.isTrusted && (Math.abs(e.movementX) > 1 || Math.abs(e.movementY) > 1)) userInput('mouse');
  }, opts);
  for (const type of ['mousedown', 'keydown', 'wheel', 'touchstart']) {
    window.addEventListener(type, (e) => { if (e.isTrusted) userInput(type); }, opts);
  }

  function showLast(l) {
    pill.title = l ? 'Last stop: ' + l.reason + ' (' + new Date(l.at).toLocaleTimeString() + ')' : '';
  }

  gear.addEventListener('pointerdown', (e) => e.stopPropagation());
  gear.addEventListener('pointerup', (e) => e.stopPropagation());
  gear.addEventListener('click', (e) => {
    e.stopPropagation();
    try { chrome.runtime.sendMessage({ type: 'openOptions' }); } catch (err) {}
  });

  let drag = null;
  pill.addEventListener('pointerdown', (e) => {
    if (!e.isTrusted || e.button !== 0) return;            // ignore script-generated events
    pill.setPointerCapture(e.pointerId);
    const r = host.getBoundingClientRect();
    drag = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, moved: false, t: Date.now() };
  });
  pill.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (Math.abs(dx) + Math.abs(dy) > 5) drag.moved = true;
    if (drag.moved) placePx(drag.ox + dx, drag.oy + dy);
  });
  pill.addEventListener('pointercancel', () => { drag = null; });
  pill.addEventListener('pointerup', (e) => {
    if (!drag) return;
    const d = drag;
    drag = null;
    if (!e.isTrusted) return;
    try {
      if (d.moved) {
        chrome.runtime.sendMessage({ type: 'savePos', pos });
        return;
      }
      const sinceVisible = Math.round(performance.now() - visibleAt);
      if (sinceVisible < 1500) return;                     // tab was only just shown: not a deliberate click
      if (Date.now() - d.t > 1500) return;                 // press was held far too long: not a click
      chrome.runtime.sendMessage({
        type: 'toggle',
        info: { trusted: e.isTrusted, pointerType: e.pointerType, sinceVisibleMs: sinceVisible, heldMs: Date.now() - d.t }
      });
    } catch (err) { /* extension was reloaded; refresh the page */ }
  });

  load();
})();
